<?php
 phpinfo();
 ?>